


#include "framework.h"
#include "emulator.h"


#pragma warning( disable : 4996 4244)

void emulator_run()
{
	
}


void emulator_init(int argc, char** argv)
{
	
	
}

void emulator_end()
{



}