#pragma once

void emulator_init(int argc, char** argv);
void emulator_run();
void emulator_end();