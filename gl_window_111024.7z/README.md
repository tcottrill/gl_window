# GL_WINDOW

This is just a basic Win32 Window that I use as a base for my test programs. Archiving here so I stop trying to recreate the wheel every time. Not a lot of extras, just an OpenGL Window with OpenGL 2/3/4 and a basic shader linker, command line processing and Windows 10 Window handling. 


